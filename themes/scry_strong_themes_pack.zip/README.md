# Scry Strong Theme Pack

Included themes:
- `midnight-commander`
- `neon-cathedral`
- `emerald-overdrive`
- `amber-voltage`
- `violet-supernova`
- `solar-anarchy`
- `toxic-orchid`
- `crimson-reactor`
- `cobalt-tempest`
- `hellfire-cyan`

Install:

```bash
mkdir -p ~/.config/scry/themes
cp *.toml ~/.config/scry/themes/
```

Activate one in `~/.config/scry/scry.toml`:

```toml
theme = "midnight-commander"
```
