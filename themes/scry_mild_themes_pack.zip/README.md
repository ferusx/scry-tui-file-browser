# Scry Mild Theme Pack

Included themes:
- `lush-emerald`
- `tarnished-blue`
- `rimfrost`
- `lotus-moment`
- `aum`
- `obsidian-frost`
- `purple-haze`
- `sundsvall-brinner`
- `black-ivory`
- `blood-red-winter`

Install:

```bash
mkdir -p ~/.config/scry/themes
cp *.toml ~/.config/scry/themes/
```

Activate one in `~/.config/scry/scry.toml`:

```toml
theme = "lush-emerald"
```
